      PARAMETER (maxtask = 200)

      integer INEWCOMM
      integer sevsegtype(maxtask,15)

      common /newcom/ INEWCOMM
      common /newtyp/ sevsegtype
