extern int field_flag=0;
extern int f_descriptor=0;
