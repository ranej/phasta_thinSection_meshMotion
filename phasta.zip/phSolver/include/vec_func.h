#include <math.h>

void diffVt(double vec1[3],double vec2[3], double ans[3]);
void crossProd(double a[3], double b[3], double ans[3]);
double dotProd(double a[3], double b[3]);
double vecMag(double a[3]);
int vecEqual(double a[3], double b[3]);



