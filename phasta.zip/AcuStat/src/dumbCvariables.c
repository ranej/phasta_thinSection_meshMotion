int field_flag=0;
int f_descriptor=0;
