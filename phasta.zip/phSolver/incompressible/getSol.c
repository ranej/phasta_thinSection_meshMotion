#include "usr.h"
/*#include "rts.h" */
void getSol ( UsrHd usrHd,
              double* Dy  )
{

     Dy = usrHd->solinc;
     
/* extern int rts_getavailablememory(size_t* availableMemory);
*/

}
