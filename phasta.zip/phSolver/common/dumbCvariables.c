#include "phIO.h"
int field_flag=0;
phio_fp f_descriptor=0;
